module.exports = handlers => ({
  method: 'POST',
  path: '/avatar',
  handler: handlers.avatar
})
