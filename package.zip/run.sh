#!/bin/bash

echo "starting avatar-maker"
cd /home/ec2-user/avatar-maker
npm start
