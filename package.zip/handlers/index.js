module.exports = {
  login: require('./login'),
  logout: require('./logout'),
  main: require('./main'),
  make: require('./make'),
  avatar: require('./avatar'),
  register: require('./register'),
  features: require('./features'),
  user: require('./user')
}
